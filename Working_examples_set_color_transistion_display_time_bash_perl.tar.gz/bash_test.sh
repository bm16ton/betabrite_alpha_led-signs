#!/bin/bash
printf '\001'"Z""00"'\002'"AA"'\x1B'" t"'\x1C\x41'" Bens a GOD!! "'\004'

