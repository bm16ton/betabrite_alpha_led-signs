#!/usr/bin/perl
# Get the attention of the sign
print "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";

print "\001" . "Z" . "00" . "\002" . "E" . " " . "1722" . "\004";
