#!/usr/bin/perl
# Get the attention of the sign
print "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";

# Tell the sign to print the message
$message = "   Hello        World!";
print "\001" . "Z" . "00" . "\002" . "AA" . "\x1B" . " \x74" . "\x1C\x41" . $message . "\x1B" . "\x0C" . " \x1c\x65" . "\x1C\x31" . "\x13" . "\004";
#print "\001" . "Z" . "00" . "\002" . "AA" . "\x1B" . "\x6F" . " \x69" . "\004";
#print "\001" . "Z" . "00" . "\002" . "AA" . "a" . "\x1B" . " \x69" . $message . "\004";


# a = reg font tilted right right to left scroll
# t = small font right to left scroll
# s = just show up
# d = random
# k = wipe right to left
# p = disapears from top down and bottom up at same time

# COLORS
# COLOR_RED "\x1C\x31"
# COLOR_GREEN "\x1C\x32"
# COLOR_AMBER "\x1C\x33"
# COLOR_DIMRED "\x1C\x34"
# COLOR_DIMGREEN "\x1C\x35"
# COLOR_BROWN "\x1C\x36"
# COLOR_ORANGE "\x1C\x37"
# COLOR_YELLOW "\x1C\x38"
# COLOR_RAINBOW1 "\x1C\x39"
# COLOR_RAINBOW2 "\x1C\x41"
# COLOR_MIX "\x1C\x42"
# COLOR_AUTO "\x1C\x43"

# \x0C  NEW PAGE
# \x0D  NEW LINE

# \x13  show time

################# add \x1C before mode if changing from inside txt
# MODES 
# ROTATE "\x61"
# HOLD "\x62"
# FLASH "\x63"
# ROLL_UP "\x65"
# ROLL_DOWN "\x66"
# ROLL_LEFT "\x67"
# ROLL_RIGHT "\x68"
# WIPE_UP "\x69"
# WIPE_DOWN "\x6a"
# WIPE_LEFT "\x6b"
# WIPE_RIGHT "\x6c"
# SCROLL "\x6d"
# AUTOMODE "\x6f"
# ROLL_IN "\x70"
# ROLL_OUT "\x71"
# WIPE_IN "\x72"
# WIPE_OUT "\x73"
# COMPRESSED_ROTATE "\x74"
# TWINKLE "\x6e\x30"
# SPARKLE "\x6e\x31"
# SNOW "\x6e\x32"
# INTERLOCK "\x6e\x33"
# SWITCH "\x6e\0x34"
# SLIDE "\x63\0x35"
# SPRAY "\x63\0x36"
# STARBURST "\x63\0x37"
# WELCOME "\x63\0x38"
# SLOT_MACHINE "\x63\0x39"

